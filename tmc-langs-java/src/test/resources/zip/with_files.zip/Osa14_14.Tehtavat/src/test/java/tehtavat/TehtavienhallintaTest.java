package tehtavat;

import org.junit.Test;


public class TehtavienhallintaTest {
    @Test
    public void test() {
        System.out.println("herpyderp");
    }
}
