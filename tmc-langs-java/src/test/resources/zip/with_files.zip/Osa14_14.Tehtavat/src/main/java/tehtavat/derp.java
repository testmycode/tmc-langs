/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tehtavat;

/**
 *
 * @author ronttiantti
 */
public class derp {
    public void herp() {
        System.out.println("derp");
    }
}
