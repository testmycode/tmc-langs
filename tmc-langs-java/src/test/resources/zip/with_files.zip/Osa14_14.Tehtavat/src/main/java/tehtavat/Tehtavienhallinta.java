package tehtavat;

public class Tehtavienhallinta {
    public void derp() {
        System.out.println("herpyderp");
    }
}
