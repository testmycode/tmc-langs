
public class Studentfile {

    private int loller;

    public Studentfile() {
        this.loller = 101;
    }
}