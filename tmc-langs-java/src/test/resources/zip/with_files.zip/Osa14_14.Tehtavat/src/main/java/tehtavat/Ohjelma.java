package tehtavat;

public class Ohjelma {

    public static void main(String[] args) {
        // voit testata sovelluksen toimintaa täällä -- hyödynnä toki
        // myös kehittämiäsi automaattisia testejä
    }

    public static int osiaToteutettu() {
        System.out.println("herpyderp");
        return 0;
    }
}
